import echarts from '@/utils/contants/echarts';
import { useEffect, useState } from 'react';
import { getAnswerList } from '@/api/studentAnswer';
import stores from '@/stores';
import './index.scss';
import { table } from 'console';

type EChartsOption = any;

export default function ScoreLie() {
  const [chartData, setChartData] = useState({
    correctCount: 0,
    inCorrectCount: 0,
    noAnswer: 0
  });

  useEffect(() => {
    const fetchAndRenderChart = async () => {
      // 1. 获取答案数据
      const answerRes = stores.AnswerStore.tableData
      // 2. 计算正确和错误数量
      let correctCount = 0;
      let inCorrectCount = 0;
      let noAnswer = 0;

      if (answerRes) {
        answerRes.forEach((item: any) => {
          if (item.isCorrect === 1) {
            correctCount++;
          } else if (item.isCorrect === 0) {
            inCorrectCount++;
          }
          // 检查是否有未作答的题目
          if (!item.studentAnswer || item.studentAnswer.trim() === '') {
            noAnswer++;
          }
        });
      }

      // 3. 更新状态
      setChartData({ correctCount, inCorrectCount, noAnswer });

      // 4. 渲染图表
      const chartDom = document.getElementsByClassName('scorepie')[0];
      if (chartDom && echarts) {
        const myChart = echarts.init(chartDom);

        const option: EChartsOption = {
          color: ['#22c17c', '#f05533', '#e2e2e2'],
          title: {
            text: '题目正确分布',
            subtext: '',
            left: '10px',
            top: '10px',
          },
          tooltip: {
            trigger: 'item'
          },
          legend: {
            orient: 'vertical',
            left: '10px',
            top: '45px',
          },
          series: [
            {
              name: '',
              type: 'pie',
              radius: '50%',
              center: ['60%', '40%'],
              label: {
                show: true,
                formatter: '{b}: {c} ({d}%)'
              },
              data: [
                { value: correctCount, name: '正确' },
                { value: inCorrectCount, name: '错误' },
                { value: noAnswer, name: '未做' },
              ],
              emphasis: {
                itemStyle: {
                  shadowBlur: 2,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              }
            }
          ]
        };

        myChart.setOption(option);

        // 5. 监听窗口变化，重新渲染图表
        // const handleResize = () => {
        //   myChart.resize();
        // };

        // window.addEventListener('resize', handleResize);

        // return () => {
        //   window.removeEventListener('resize', handleResize);
        //   myChart.dispose();
        // };
      }
    };

    if (stores.ExamStore.paperId && stores.UserStore.userId) {
      fetchAndRenderChart();
    }
  }, [stores.ExamStore.paperId, stores.UserStore.userId, stores.AnswerStore.tableData]); // 添加依赖项

  return (
    <div className='scorepie'></div>
  );
}